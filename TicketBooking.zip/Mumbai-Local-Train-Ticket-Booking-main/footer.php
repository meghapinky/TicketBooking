
<head>
  <style>

footer {

  
    font-family: Montserrat, sans-serif;
    margin-bottom: 0;
    background-color: #2d2d30;
    border: 0;
    font-size: 18px !important;
    letter-spacing: 2px;
    opacity: 5;
    padding: 10px;
    border-radius: 0;

    }
  </style>
<body>
  <br>
  <br>
  <br>
  <br>
<br>
  <br>
<br>
  <br>
<br>
  <br>

<footer class="text-center">
 

  
<div align="right"></div>
 <a href="#" style="color: white; text-decoration: none"> <img src="https://img.icons8.com/color/60/000000/facebook.png"/></a>&nbsp&nbsp&nbsp
   <a href="#" style="color: white; text-decoration: none"> <img src="https://img.icons8.com/color/60/000000/instagram-new.png"/></a>
    <br>
  <h3><img src="copy.ico" width="20px"><a style="color: white; text-decoration: none">&nbspM-TICKET</a></h3>


</div>
</footer>
</body></head>